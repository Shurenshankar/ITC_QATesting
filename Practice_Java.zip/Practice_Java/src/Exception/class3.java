package Exception;

public class class3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int[] numb = {10,20,30};
			System.out.println(numb[10]);
		}catch(Exception e) {
			System.out.println("Something went wrong");
		}
		finally {
			System.out.println("The try catch is executed");
		}

	}

}
