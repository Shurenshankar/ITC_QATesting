package Exception;

public class class1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hi");
		System.out.println("Hi");
		try {
		System.out.println(10/0);
		}catch(Exception e) {
			System.out.println(e.getLocalizedMessage());
		}
		System.out.println("Hi");
		System.out.println("Hi");
	}

}
