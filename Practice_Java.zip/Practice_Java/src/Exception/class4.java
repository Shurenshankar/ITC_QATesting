package Exception;

public class class4 {
	static void checkage(int age) {
		if(age<18) {
			throw new ArithmeticException("Access denied - You must be atleast 18 years old");
		}
		else {
			System.out.println("Access Granted");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		checkage(19);
	}

}
