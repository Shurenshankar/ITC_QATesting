package Exception;

public class class2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int res=10/0;
		}catch(ArithmeticException e) {
			System.out.println("Exception caught: "+e);
		}
		System.out.println("I will execute");
	}

}
