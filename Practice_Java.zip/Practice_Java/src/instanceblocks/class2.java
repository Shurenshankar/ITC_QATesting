package instanceblocks;

public class class2 {
	class2(){
		System.out.println("0 Arg constructor");
		}
	class2(int a){
		System.out.println("1 Arg cinstructor");
		}
		{
		System.out.println("instance block1");
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new class2(10);
	}

}
