package instanceblocks;

public class class1 {
	class1(){
		System.out.println("0 Arg constructor ");
		}
		{
		System.out.println("instance block");
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new class1();
	}

}
