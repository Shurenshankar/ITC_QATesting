package Arraydeque;
import java.util.*;
public class example3 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Creating empty priority queue
        PriorityQueue<String> numQueue = new PriorityQueue<String>();
        // add elements to numQueue using add()
        numQueue.add("Five");
        numQueue.add("One");
        numQueue.add("Seven");
        numQueue.add("Three");
        numQueue.add("Eleven");
        numQueue.add("Nine");
        numQueue.add("Twelve");
		
     // Print the head element using Peek () method
        System.out.println("Head element using peek method:"  + numQueue.peek());
        
        boolean ret_val = numQueue.contains("Five");
        System.out.println("\n\nPriority queue contains 'Five' "
                           + "or not?: " + ret_val);
     // get array equivalent of PriorityQueue with toArray ()
        Object[] numArr = numQueue.toArray();
        System.out.println("\nArray Contents: ");
        for (int i = 0; i < numArr.length; i++)
            System.out.print(numArr[i].toString() + " ");


	}
	}












