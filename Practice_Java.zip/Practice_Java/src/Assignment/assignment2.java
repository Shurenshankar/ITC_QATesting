package Assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Contact {
    String name, surname, phone, email, place;
    Contact(String name, String surname, String phone, String email, String place) {
        this.name = name;
        this.surname = surname;
        this.phone = phone;
        this.email = email;
        this.place = place;
    }
    public String toString() {
        return name + " " + surname + ", Phone: " + phone + ", Email: " + email + ", Place: " + place;
    }
}
public class assignment2 {
    public static void main(String[] args) {
        List<Contact> contacts = new ArrayList<>();
        contacts.add(new Contact("John", "Doe", "9876543210", "john.doe@example.com", "Chennai"));
        Scanner sc = new Scanner(System.in);
        System.out.print("Search by surname: ");
        String search = sc.nextLine().trim();
        boolean found = false;
        for (Contact c : contacts) {
            if (c.surname.equalsIgnoreCase(search)) {
                System.out.println(c);
                found = true;
            }
        }
        if (!found) System.out.println("No contacts found.");
        sc.close();
    }
}