package method;

public class class2 {
	void m1(int a ,char ch) {
		System.out.println("m1 is instance method");
		System.out.println(a);
		System.out.println(ch);
		}
	static void m2(String str,double d) {
		System.out.println("m2 is static method");
		System.out.println(str);
		System.out.println(d);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class2 c2 = new class2();
		c2.m1(10,'A');
		class2.m2("Shuren",10.66);

	}

}
