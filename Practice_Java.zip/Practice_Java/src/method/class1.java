package method;

public class class1 {
	void m1() {
		System.out.println("m1 is instance method");
	}
	static void m2() {
		System.out.println("m2 is static method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class1 c1 = new class1();
		c1.m1();
		class1.m2();

	}

}
