package inheritance;
class Q{
	Q(){
			System.out.println("Parent 0 Arg constructor");
	}
}
public class class2 extends Q{
	class2(){
		this(10);
		System.out.println("Child 0 Arg constructor");
	}
	class2(int a){
		super();
		System.out.println("Chils 1 Arg constructor");
	}
	public static void main(String[] args) {
		new class2();
	}

}
