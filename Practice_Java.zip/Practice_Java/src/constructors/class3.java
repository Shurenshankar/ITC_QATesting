package constructors;

public class class3 {
	int eid;
	String ename;
	float esal;
	
	class3(){
		eid=1001;
		ename="Shuren";
		esal=23000;
	}
	void display() {
		System.out.println("Emp ID : "+eid);
		System.out.println("Emp Name : "+ename);
		System.out.println("Emp Salary : "+esal);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class3 c3= new class3() ;
		c3.display();
}
}
