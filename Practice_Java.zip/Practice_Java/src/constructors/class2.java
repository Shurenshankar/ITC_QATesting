package constructors;

public class class2 {
	int eid;
	String ename;
	float esal;
	
	void display() {
		System.out.println("Emp ID : "+eid);
		System.out.println("Emp Name : "+ename);
		System.out.println("Emp Salary : "+esal);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class2 c2 = new class2();
		c2.display();

	}

}
