package constructors;

public class class1 {
	class1(){
		System.out.println("0 Arg constructor");
	}
	class1(int a){
		System.out.println("1 Arg constructor");
	}
	void m1() {
		System.out.println("M1 method");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class1 t = new class1();
		t.m1();
		class1 t1 = new class1(10);
		t1.m1();
	}

}
