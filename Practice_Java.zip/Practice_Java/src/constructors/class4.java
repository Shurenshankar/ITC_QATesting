package constructors;

public class class4 {
	int eid;
	String ename;
	float esal;
	class4(int a,String b,float c){
		this.eid=a;
		this.ename=b;
		this.esal=c;
	}
	void display() {
		System.out.println("Emp ID : "+eid);
		System.out.println("Emp Name : "+ename);
		System.out.println("Emp Salary : "+esal);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		class4 t = new class4(1001,"Shuren",23400.56f);
		t.display();
		class4 t1 = new class4(1002,"Raghul",25300.45f);
		t1.display();
	}

}
