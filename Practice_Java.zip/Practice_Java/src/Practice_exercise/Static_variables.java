package Practice_exercise;

public class Static_variables {
	static int a=100;
	static int b=200;
	void m1() {
		System.out.println(Static_variables.a);
		System.out.println(Static_variables.b);
	}
	public static void main(String[] args) {
		System.out.println(Static_variables.a);
		System.out.println(Static_variables.b);
		Static_variables t = new Static_variables();
		t.m1();
	}
}
