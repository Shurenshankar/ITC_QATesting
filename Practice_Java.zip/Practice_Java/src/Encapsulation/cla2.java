package Encapsulation;

public class cla2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encap2 car = new encap2("BMW",2025);
		System.out.println(car.getModel());
		System.out.println(car.getYear());
	}

}
