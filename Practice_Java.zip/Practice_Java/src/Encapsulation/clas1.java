
package Encapsulation;

public class clas1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encap1 p1 = new encap1();
		p1.setName("Shuren");
		p1.setAge(22);
		
		System.out.println("Name : "+p1.getName());
		System.out.println("Age : "+p1.getAge());
	}

}
