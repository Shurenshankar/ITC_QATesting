package Polymorphism;

public class class2 {

	// It is operator overloading
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10+20);
		System.out.println("Shuren" + "M S");
		System.out.println("Shuren" + 10);
		System.out.println("Shuren" + 10 + "M S");

	}

}
