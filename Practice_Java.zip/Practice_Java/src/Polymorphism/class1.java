package Polymorphism;

public class class1 {
	void m1(int a) {
		System.out.println("int m1 mehtod");
	}
	void m1(int a,int b) {
		System.out.println("int int m1 method");
	}
	void m1(char c) {
		System.out.println("Char m1 method");
	}

	public static void main(String[] args) {
		class1 c1 = new class1();
		c1.m1(10);
		c1.m1(20, 30);
		c1.m1('a');
	}

}
