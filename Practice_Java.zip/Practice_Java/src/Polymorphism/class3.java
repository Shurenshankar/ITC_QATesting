package Polymorphism;
class shape{
	void draw() {
		System.out.println("No shape");
	}
}
class circle extends shape{
	void draw() {
		System.out.println("Drawing circle");
	}
}
class rectangle extends shape{
	void draw() {
		System.out.println("Drawing rectangle");
	}
}
class triangle extends shape{
	void draw() {
		System.out.println("Drawing triangle");
	}
}
public class class3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		shape s = new shape();
		s.draw();
		shape s1 = new circle();
		s1.draw();
		shape s2 = new rectangle();
		s2.draw();
		shape s3 = new triangle();
		s3.draw();
		
	}

}
