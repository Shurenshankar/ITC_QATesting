package loops;

public class class1 {

	public static void main(String[] args) {
		int i=10;
		if(i==10) {
			System.out.println("i is 10");
		}
		else if(i==30) {
			System.out.println("i is 30");
		}
		else {
			System.out.println("i is neither 10 nor 30");
		}
	}

}
