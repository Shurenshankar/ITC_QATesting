package loops;

public class class2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=1;
		switch(n++) {
		case 1:
			System.out.println("Hi team");
			break;
		case 2:
			System.out.println("Hello team");
			break;
		default:
			System.out.println("bye team");
		}
	}

}
