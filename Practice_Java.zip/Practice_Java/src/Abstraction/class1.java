package Abstraction;
abstract class birla{
	abstract void printinfo();
}
class Employee extends birla{
	void printinfo() {
		String name = "Text";
		int age =21;
		float salary = 2222.2f;
		
		System.out.println(name);
		System.out.println(age);
		System.out.println(salary);
	}
}
public class class1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		birla s = new Employee();
		s.printinfo();
	}

}
