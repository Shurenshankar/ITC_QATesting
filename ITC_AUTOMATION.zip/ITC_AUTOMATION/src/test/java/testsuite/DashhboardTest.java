package testsuite;

import org.testng.annotations.Test;

public class DashhboardTest {
  @Test
  public void testDashboardLoad() {
	  System.out.println("Dashboard loaded");
  }
}
