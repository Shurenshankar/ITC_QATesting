package datadriven;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
public class datadrvtest {
    WebDriver driver;
    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/");
    }
    @DataProvider(name = "loginData")
    public Object[][] loginDataProvider() {
        return new Object[][] {
            {"", "Password123"},
            {"student", "SuperSecretPassword"},
            {"student", "Password123"},
            {"", ""},
            {"student", ""}
        };
    }
    @Test(dataProvider = "loginData")
    public void testLogin(String username, String password) {
        WebElement usernameField = driver.findElement(By.id("username"));
        WebElement passwordField = driver.findElement(By.id("password"));
        WebElement loginBtn = driver.findElement(By.id("submit"));
        usernameField.clear();
        usernameField.sendKeys(username);
        passwordField.clear();
        passwordField.sendKeys(password);
        loginBtn.click();
        // You can add validation/assertion here
        System.out.println("Tested login with: " + username + " / " + password);
    }
    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}

