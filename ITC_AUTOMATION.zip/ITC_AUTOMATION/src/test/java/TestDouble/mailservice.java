package TestDouble;

public interface mailservice {
	void sendEmail(String message);
}
