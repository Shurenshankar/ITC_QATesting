package TestDouble;

public class DummyEmailService implements mailservice{
	
	public void sendEmail(String message) {
		// do nothing
	}
}
