package TestDouble;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ReportServiceTest {
	
	@Test
	public void testGenerateReport() {
		mailservice dummyemail = new DummyEmailService();
		reportservice rs = new reportservice(dummyemail);
		
		String result = rs.generatereport();
		Assert.assertEquals(result, "Report Generated");
	}

}
