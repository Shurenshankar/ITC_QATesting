package TestNG;

import org.testng.annotations.Test;
public class grouptest {
    @Test(groups = {"smoke","Priority=1"})
    public void loginTest() {
        System.out.println("Smoke: Login Test");
    }
    @Test(groups = {"smoke", "regression"})
    public void searchTest() {
        System.out.println("Smoke + Regression: Search Test");
    }
    @Test(groups = {"regression"})
    public void addToCartTest() {
        System.out.println("Regression: Add to Cart Test");
    }
    @Test(groups = {"sanity"})
    public void profileUpdateTest() {
        System.out.println("Sanity: Profile Update Test");
    }
    @Test
    public void aboutPageTest() {
        System.out.println("No Group: About Page Test");
    }
}