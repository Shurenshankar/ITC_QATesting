package TestNG;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import io.github.bonigarcia.wdm.WebDriverManager;
public class button {
    WebDriver driver;
    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.selenium.dev/selenium/web/web-form.html");
    }
    @Test
    public void verifySubmitButtonColor() {
        // Locate the button
        WebElement submitButton = driver.findElement(By.cssSelector("button[type='submit']"));
        // Get the background-color CSS value
        String color = submitButton.getCssValue("background-color");
        // Print actual color (for reference)
        System.out.println("Button color: " + color);  // e.g., rgba(13, 110, 253, 1)
        // Assert expected color (example: Bootstrap blue = rgba(13, 110, 253, 1))
        String expectedColor = "rgba(13, 110, 253, 1)";
        Assert.assertEquals(color, expectedColor, "Button color mismatch!");
    }
    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}