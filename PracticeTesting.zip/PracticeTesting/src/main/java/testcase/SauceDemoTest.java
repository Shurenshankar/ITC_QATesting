package testcase;

import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pom.CartPage;
import pom.InventoryPage;
import pom.LoginPage;
import pom.CheckoutPage;
import pom.CheckoutCompletePage;
import pom.MenuSidebarPage;
import testsetup.BaseTest;

public class SauceDemoTest extends BaseTest {

    private LoginPage loginPage;
    private InventoryPage inventoryPage;
    private CartPage cartPage;
    private CheckoutPage checkoutPage;
    private CheckoutCompletePage checkoutCompletePage;
    private MenuSidebarPage menuSidebarPage;

    @BeforeMethod
    public void setUpPages() {
        loginPage = new LoginPage(driver);
        inventoryPage = new InventoryPage(driver);
        cartPage = new CartPage(driver);
        checkoutPage = new CheckoutPage(driver);
        checkoutCompletePage = new CheckoutCompletePage(driver);
        menuSidebarPage = new MenuSidebarPage(driver);
    }

    // ----------------- DATAPROVIDERS ------------------

    @DataProvider(name = "validLoginData")
    public Object[][] validLoginData() {
        return new Object[][]{
            {"standard_user", "secret_sauce"}
        };
    }

    @DataProvider(name = "invalidLoginData")
    public Object[][] invalidLoginData() {
        return new Object[][]{
            {"standard_user", "wrong_password"},
            {"locked_out_user", "secret_sauce"},
            {"", "secret_sauce"},
            {"standard_user", ""},
            {"", ""}
        };
    }

    @DataProvider(name = "userInfoData")
    public Object[][] userInfoData() {
        return new Object[][]{
            {"Shuren", "Shanker", "638002"},
            {"", "", ""}  // For negative test case
        };
    }

    // ----------------- LOGIN TESTS ------------------

    @Test(priority = 2, dataProvider = "validLoginData")
    public void testValidLogin(String username, String password) {
        loginPage.login(username, password);
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "Login should navigate to inventory page.");
    }

    @Test(priority = 1, dataProvider = "invalidLoginData")
    public void testInvalidLogin(String username, String password) {
        loginPage.login(username, password);
        Assert.assertTrue(loginPage.getErrorMessage().length() > 0, "Should display error on invalid login.");
    }

    // ----------------- INVENTORY TESTS ------------------

    @Test(priority = 3)
    public void testAddBackpackToCartStaysOnInventory() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));
    }

    @Test(priority = 4)
    public void testGoToCartNavigatesToCartPage() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.goToCart();
        Assert.assertTrue(driver.getCurrentUrl().contains("cart.html"));
    }

    @Test(priority = 5)
    public void testInventoryItemCountIsSix() {
        loginPage.login("standard_user", "secret_sauce");
        int count = inventoryPage.getInventoryCount();
        Assert.assertEquals(count, 6);
    }

    // ----------------- CART TESTS ------------------

    @Test(priority = 6)
    public void testCartItemCountIsOne() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        int count = cartPage.getCartItemCount();
        Assert.assertEquals(count, 1);
    }

    @Test(priority = 7)
    public void testRemoveItemFromCart() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.removeBackpack();
        int count = cartPage.getCartItemCount();
        Assert.assertEquals(count, 0);
    }

    @Test(priority = 8)
    public void testClickCheckoutNavigatesToCheckoutPage() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.clickCheckout();
        Assert.assertTrue(driver.getCurrentUrl().contains("checkout-step-one"));
    }

    @Test(priority = 9)
    public void testClickContinueShoppingNavigatesToInventory() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.clickContinueShopping();
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));
    }

    // ----------------- CHECKOUT PAGE TESTS ------------------

    @Test(priority = 10, dataProvider = "userInfoData")
    public void testCheckoutFormSubmission(String fName, String lName, String zip) {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.clickCheckout();
        checkoutPage.fillCheckoutForm(fName, lName, zip);

        if (fName.isEmpty()) {
            Assert.assertTrue(checkoutPage.getErrorMessage().contains("First Name is required"));
        } else {
            Assert.assertTrue(driver.getCurrentUrl().contains("checkout-step-two"));
        }
    }

    @Test(priority = 11)
    public void testCartItemCountAndPriceSummary() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.clickCheckout();
        checkoutPage.fillCheckoutForm("Shuren", "Shanker", "638002");
        Assert.assertEquals(checkoutPage.getCartItemCount(), 1);
        Assert.assertTrue(checkoutPage.getItemTotal().contains("Item total"));
    }

    // ----------------- CHECKOUT COMPLETE PAGE TESTS ------------------

    @Test(priority = 12)
    public void testClickFinishShowsCompleteMessage() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.clickCheckout();
        checkoutPage.fillCheckoutForm("Shuren", "Shanker", "638002");
        checkoutPage.clickFinish();
        Assert.assertTrue(checkoutCompletePage.getCompleteHeader().contains("Thank you"));
    }

    @Test(priority = 13)
    public void testBackToHomeFromCheckoutComplete() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.clickCheckout();
        checkoutPage.fillCheckoutForm("Shuren", "Shanker", "638002");
        checkoutPage.clickFinish();
        checkoutCompletePage.clickBackHome();
        Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));
    }

    @Test(priority = 14)
    public void testFinishButtonCompletesOrder() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        inventoryPage.goToCart();
        cartPage.clickCheckout();
        checkoutPage.fillCheckoutForm("Shuren", "Shanker", "638002");
        checkoutPage.clickFinish();
        String message = checkoutCompletePage.getCompleteHeader();
        Assert.assertEquals(message, "Thank you for your order!");
    }

    // ----------------- MENU SIDEBAR TESTS ------------------

    @Test(priority = 15)
    public void testLogoutFromSidebar() {
        loginPage.login("standard_user", "secret_sauce");
        menuSidebarPage.openMenu();
        menuSidebarPage.clickLogout();
        Assert.assertTrue(driver.getCurrentUrl().contains("saucedemo"));
    }

    @Test(priority = 16)
    public void testResetSidebarResetsCart() {
        loginPage.login("standard_user", "secret_sauce");
        inventoryPage.addBackpackToCart();
        menuSidebarPage.openMenu();
        menuSidebarPage.clickReset();
        inventoryPage.goToCart();
        Assert.assertEquals(cartPage.getCartItemCount(), 0);
    }

    @Test(priority = 17)
    public void testMenuOpenDisplaysOptions() {
        loginPage.login("standard_user", "secret_sauce");
        menuSidebarPage.openMenu();
        Assert.assertTrue(true, "Menu did not open successfully.");
    }
}
