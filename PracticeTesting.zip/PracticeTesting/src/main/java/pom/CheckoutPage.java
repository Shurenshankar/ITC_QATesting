package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
    private WebDriver driver;

    // Step One Locators
    private By firstName = By.id("first-name");
    private By lastName = By.id("last-name");
    private By postalCode = By.id("postal-code");
    private By continueButton = By.id("continue");
    private By errorMessage = By.cssSelector("h3[data-test='error']");

    // Step Two Locators
    private By finishButton = By.id("finish");
    private By itemTotal = By.cssSelector(".summary_subtotal_label");
    private By tax = By.cssSelector(".summary_tax_label");
    private By total = By.cssSelector(".summary_total_label");
    private By cartItems = By.className("cart_item");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }

    // Step One Methods
    public void enterFirstName(String fname) {
        driver.findElement(firstName).clear();
        driver.findElement(firstName).sendKeys(fname);
    }

    public void enterLastName(String lname) {
        driver.findElement(lastName).clear();
        driver.findElement(lastName).sendKeys(lname);
    }

    public void enterPostalCode(String code) {
        driver.findElement(postalCode).clear();
        driver.findElement(postalCode).sendKeys(code);
    }

    public void clickContinue() {
        driver.findElement(continueButton).click();
    }

    public String getErrorMessage() {
        return driver.findElement(errorMessage).getText();
    }

    public void fillCheckoutForm(String fname, String lname, String postal) {
        enterFirstName(fname);
        enterLastName(lname);
        enterPostalCode(postal);
        clickContinue();
    }

    // Step Two Methods
    public int getCartItemCount() {
        return driver.findElements(cartItems).size();
    }

    public String getItemTotal() {
        return driver.findElement(itemTotal).getText();
    }

    public String getTax() {
        return driver.findElement(tax).getText();
    }

    public String getTotal() {
        return driver.findElement(total).getText();
    }

    public void clickFinish() {
        driver.findElement(finishButton).click();
    }
}
