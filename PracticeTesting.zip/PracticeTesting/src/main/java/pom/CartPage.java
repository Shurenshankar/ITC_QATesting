package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CartPage {
    private WebDriver driver;
    private By cartItems = By.className("cart_item");
    private By removeBackpack = By.id("remove-sauce-labs-backpack");
    private By checkoutButton = By.id("checkout");
    private By continueShopping = By.id("continue-shopping");

    public CartPage(WebDriver driver) {
        this.driver = driver;
    }

    public int getCartItemCount() {
        return driver.findElements(cartItems).size();
    }
    public void removeBackpack() {
        driver.findElement(removeBackpack).click();
    }
    public void clickCheckout() {
        driver.findElement(checkoutButton).click();
    }
    public void clickContinueShopping() {
        driver.findElement(continueShopping).click();
    }
}
