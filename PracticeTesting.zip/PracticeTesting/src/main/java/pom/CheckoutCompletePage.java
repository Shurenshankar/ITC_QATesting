package pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutCompletePage {
    private WebDriver driver;
    private By header = By.className("complete-header");
    private By backHome = By.id("back-to-products");

    public CheckoutCompletePage(WebDriver driver) {
        this.driver = driver;
    }

    public String getCompleteHeader() {
        return driver.findElement(header).getText();
    }
    public void clickBackHome() {
        driver.findElement(backHome).click();
    }
}
